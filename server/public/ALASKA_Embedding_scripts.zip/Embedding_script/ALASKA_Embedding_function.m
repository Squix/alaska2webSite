%Embedding settings:
tStart=tic;

%Defining first the probability of using each embedding scheme
prob_JUNI=0.4
prob_nsF5=0.15
prob_EBS=0.15
prob_UED=0.3

% Those are the two thresholds used to adjust the effect of both unsharpening and denoising
USM_thres_high=1000;
USM_thres_low=500;

DEN_thres_high=60;
DEN_thres_low=20;

% Create the corresponding stego folder (warning !! it is exist, we clear everything from it !)
% Beware that, though the outpath can be changed, default configuration puts everything in the same directory where cover folder is !
if exist('../Conversion_script/devHome/TRAINING_DATASET_STEGO/') 
    delete('../Conversion_script/devHome/TRAINING_DATASET_STEGO/*')
    rmdir('../Conversion_script/devHome/TRAINING_DATASET_STEGO')
end
mkdir('../Conversion_script/devHome/TRAINING_DATASET_STEGO/');


base_payload=[80000, 50000, 50000, 20000]
s = RandStream('mt19937ar','Seed',789456123);
RandStream.setGlobalStream(s);

% We use this file which results from the conversion script (a file, provided on ALASKA website, that provide all information on the developement applied to each image)
text_file = fopen('../Conversion_script/devHome/list_img_profiles.txt');
config_img = textscan(text_file,'%s', 'Delimiter', '\n');
fclose(text_file);
NB_img=numel( config_img{1} );

%This has to be uncommented to extract features
%Fcover = zeros(NB_img, 24000);
%Fstego = zeros(NB_img, 24000);

% Loop over all the images ...
for line_idx=1:NB_img
    
% Well, in fact loop over all the line of the file containing all processing information ...
% The parsing of such a file starts here, beware it has to match exactly the output of the conversion script !
    pos_deliminiter=strfind(config_img{1}{line_idx}, '|');
    
    payload_scaling_factors_parameters=ones(5,1);
    
% First, extracting image name
    img_name=config_img{1}{line_idx}(1:pos_deliminiter(1)-2);


% Second, extracting sharpening infos
    USM_first=str2num( config_img{1}{line_idx}(pos_deliminiter(2)+1:pos_deliminiter(3)-1) );
    
    USM_config=config_img{1}{line_idx}(pos_deliminiter(3):pos_deliminiter(4));
    USM_ON= contains(USM_config, 'ON');
    USM_deliminiter=strfind(USM_config, ',');
    USM_STRENGTH1=str2num( USM_config( USM_deliminiter(1)+1: USM_deliminiter(2)-1 ) );
    USM_STRENGTH2=str2num( USM_config( USM_deliminiter(2)+1: end-1 ) );
    USM_STRENGTH= USM_STRENGTH1 * USM_STRENGTH2;
    if (USM_STRENGTH > USM_thres_high)
        payload_scaling_factors_parameters(1) = 1.25^2;
    elseif (USM_STRENGTH > USM_thres_low)
        payload_scaling_factors_parameters(1) = 1.25;
    end
    
    if (USM_first==1)
        payload_scaling_factors_parameters(1) = ( payload_scaling_factors_parameters(1) - 1 )*0.6 + 1;
    end

% Third, extracting denoising config
    DEN_config=config_img{1}{line_idx}(pos_deliminiter(4):pos_deliminiter(5));
    DEN_ON= contains(DEN_config, 'ON');
    DEN_deliminiter=strfind(DEN_config, ',');
    DEN_STRENGTH=str2num( DEN_config( DEN_deliminiter(1)+1: DEN_deliminiter(2)-1 ) );
    
    if (DEN_STRENGTH > DEN_thres_high)
        payload_scaling_factors_parameters(2) = 0.8^2;
    elseif (DEN_STRENGTH > DEN_thres_low)
        payload_scaling_factors_parameters(2) = 0.8;
    else
        DEN_factor = 1;
    end
    
    if (USM_first==0)
        payload_scaling_factors_parameters(2) = ( payload_scaling_factors_parameters(2) -1 )*0.6 + 1;
    end
    

% Then, microcontrast  ...    
    MICRO_config=config_img{1}{line_idx}(pos_deliminiter(5):pos_deliminiter(6));
    MICRO_ON= contains( MICRO_config, 'ON') ;
    if ( MICRO_ON )
        payload_scaling_factors_parameters(3)=1.05;
    end
    

% Then, resizing    
    RESIZE_config=config_img{1}{line_idx}(pos_deliminiter(6):pos_deliminiter(7));
    RESIZE_ON= contains( RESIZE_config, 'ON') ;
    if ( RESIZE_ON )
        payload_scaling_factors_parameters(4)=0.95;
    end
    

% eventually image size ...
    CROP_config=config_img{1}{line_idx}(pos_deliminiter(7):pos_deliminiter(8));
    CROP_xpos=strfind(CROP_config, 'x');
    CROP_size1=str2num(CROP_config(2:CROP_xpos-1));
    CROP_size2=str2num(CROP_config(CROP_xpos+1:end-1));
    
    payload_scaling_factors_parameters(5) = sqrt( (CROP_size1 * CROP_size2)/512/512 );
    
% and JPEG compression / quality factor
    QF_config=config_img{1}{line_idx}(pos_deliminiter(8)+1:end);
    QF_config=str2num(QF_config);
    
    payload_scaling_factors_parameters(6) = (0.8).^( sqrt(100-QF_config)*1.15);
    beta_payload = (QF_config-75)/150+0.2;

% Adjusting the payload consequently
    payload_scale_factor=prod(payload_scaling_factors_parameters);

% The parsing of the image configuration is now over, we can start the embedding process !
    
% Reading the image 

    imtest=jpeg_read(['../Conversion_script/devHome/TRAINING_DATASET/' img_name '.jpg']);
%This has to be uncommented to extract features and store information relative to embedding adjustment
%    Fcover( line_idx,:)=DCTR_color(imtest,  QF_config); 
% toss a random variable (uniformly distributed in [0;1] and according to its output value, pick the corresponding embedding scheme)
    rnd_nbr=rand(1);
    if rnd_nbr <= prob_JUNI
        Emb_scheme=1;
        payload_TBE= round( base_payload(1) * payload_scale_factor );
        fprintf('CALL JUNI with payload %d \n', payload_TBE);
        %CALL EMBEDDING FUNCTION
        tmp_stego = J_UNIWARD_color_cstePayload(imtest , payload_TBE, beta_payload);
    elseif rnd_nbr <= prob_JUNI + prob_EBS
        Emb_scheme=2;
        payload_TBE= round( base_payload(2) * payload_scale_factor );
        fprintf('CALL EBS with payload %d \n', payload_TBE);
        tmp_stego = EBS_color_cstePayload(imtest , payload_TBE, beta_payload);
    elseif rnd_nbr <= prob_JUNI + prob_EBS + prob_UED
        Emb_scheme=3;
        payload_TBE= round( base_payload(3) * payload_scale_factor );
        fprintf('CALL UED with payload %d \n', payload_TBE);
        tmp_stego = UED_color_cstePayload(imtest , payload_TBE, beta_payload);
    else 
        Emb_scheme=4;
        payload_TBE= round( base_payload(4) * payload_scale_factor );
        fprintf('CALL nsF5 with payload %d \n', payload_TBE);
        tmp_stego = nsf5_simulation_cste_payload_color(imtest , payload_TBE, beta_payload , cputime);
    end
    
%This has to be uncommented to extract features and store information relative to embedding adjustment
%    Fstego( line_idx,:)=DCTR_color(tmp_stego,  QF_config); 
% Eventually, write out the jpeg stego file !
    
    jpeg_write(tmp_stego , ['../Conversion_script/devHome/TRAINING_DATASET_STEGO/' img_name '.jpg']);
    PAYLOAD_FACTORS_ALL(line_idx,:) =  [ payload_scale_factor, Emb_scheme , payload_scaling_factors_parameters' ];
    
    % Print / output time elasped, but it makes no sense with parfor loop ....
%    if ( mod(line_idx,100)==0)
%        tNow=toc(tStart);
%        fprintf("Image Number %5.0d processed, time = %4.2f \n " , line_idx , tNow)
%    end
end

%This has to be uncommented to extract features and store information relative to embedding adjustment
%save('./ALASKA_embedding_infos.mat', '-v7.3', 'PAYLOAD_FACTORS_ALL')
%save('./ALASKA_fetures.mat', '-v7.3', 'Fstego', 'Fcover')

% That's all folks